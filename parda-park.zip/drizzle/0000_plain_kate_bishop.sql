CREATE TABLE `daily_sales` (
	`id` integer PRIMARY KEY AUTOINCREMENT NOT NULL,
	`date` text NOT NULL,
	`device` text NOT NULL,
	`tickets` integer NOT NULL,
	`revenue` integer NOT NULL
);
--> statement-breakpoint
CREATE TABLE `prices` (
	`id` integer PRIMARY KEY AUTOINCREMENT NOT NULL,
	`device` text NOT NULL,
	`price` integer NOT NULL,
	`date` text NOT NULL,
	`description` text
);
