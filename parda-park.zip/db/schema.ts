import { sqliteTable, text, integer, real } from 'drizzle-orm/sqlite-core';

export const prices = sqliteTable('prices', {
  id: integer('id').primaryKey({ autoIncrement: true }),
  device: text('device').notNull(),        // مثلاً "گرید", "لیزر"
  price: integer('price').notNull(),       // قیمت هر تیکت
  date: text('date').notNull(),            // تاریخ شمسی یا میلادی
  description: text('description'),
});

export const dailySales = sqliteTable('daily_sales', {
  id: integer('id').primaryKey({ autoIncrement: true }),
  date: text('date').notNull(),            // تاریخ شمسی
  device: text('device').notNull(),
  tickets: integer('tickets').notNull(),
  revenue: integer('revenue').notNull(),   // محاسبه شده: tickets * price
});