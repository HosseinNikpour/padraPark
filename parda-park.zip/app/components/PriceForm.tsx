'use client';

import { useState, useEffect } from 'react';
import { getPrices, addPrice } from '../actions';
const devices = ['گرید', 'لیزر میز', 'گردونه', 'ارنا', 'لیزر تگ', 'پکیج 4 تایی', 'پکیج 5 تایی'];

export default function PriceForm() {
  const [priceList, setPriceList] = useState<any[]>([]);
  const [newPrice, setNewPrice] = useState({ device: '', price: 0, description: '' });
  const [loading, setLoading] = useState(false);

  const loadPrices = async () => {
    const result = await getPrices();
    setPriceList(result);
  };

  useEffect(() => {
    loadPrices();
  }, []);

const savePrice = async () => {
console.log('in method');
  if (!newPrice.device || newPrice.price <= 0) {
    alert('لطفاً دستگاه و قیمت معتبر وارد کنید');
    return;
  }

    setLoading(true);
  const result = await addPrice(newPrice.device, newPrice.price, newPrice.description);
  console.log(result);
  if (result.success) {
    alert('✅ قیمت جدید ذخیره شد');
    setNewPrice({ device: '', price: 0, description: '' });
    loadPrices();   // بروزرسانی لیست
  } else {
    alert('خطا در ذخیره قیمت');
  }
    setLoading(false);
  };

  return (
    <div className="bg-white p-6 rounded-xl shadow">
      <h2 className="text-2xl font-bold mb-6">ثبت قیمت پایه دستگاه‌ها</h2>
      
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-8">
        <select 
          value={newPrice.device} 
          onChange={(e) => setNewPrice({...newPrice, device: e.target.value})}
          className="border p-3 rounded-lg"
        >
          <option value="">انتخاب دستگاه</option>
          {devices.map(d => <option key={d} value={d}>{d}</option>)}
        </select>

        <input 
          type="number" 
          placeholder="قیمت هر تیکت (ریال)" 
          value={newPrice.price} 
          onChange={(e) => setNewPrice({...newPrice, price: Number(e.target.value)})} 
          className="border p-3 rounded-lg" 
        />

        <input 
          type="text" 
          placeholder="توضیحات (اختیاری)" 
          value={newPrice.description}
          onChange={(e) => setNewPrice({...newPrice, description: e.target.value})} 
          className="border p-3 rounded-lg" 
        />
      </div>

      <button 
        onClick={savePrice} 
        disabled={loading}
        className="bg-blue-600 text-white px-8 py-3 rounded-lg hover:bg-blue-700 disabled:opacity-50"
      >
        {loading ? 'در حال ذخیره...' : 'ذخیره قیمت جدید'}
      </button>

      <div className="mt-8">
        <h3 className="font-bold mb-4">قیمت‌های ثبت شده</h3>
        <table className="w-full border-collapse border">
          <thead>
            <tr className="bg-gray-100">
              <th className="border p-3">دستگاه</th>
              <th className="border p-3">قیمت تیکت</th>
              <th className="border p-3">تاریخ</th>
              <th className="border p-3">توضیحات</th>
            </tr>
          </thead>
          <tbody>
            {priceList.map((p, i) => (
              <tr key={i}>
                <td className="border p-3">{p.device}</td>
                <td className="border p-3">{p.price.toLocaleString('fa-IR')}</td>
                <td className="border p-3">{p.date}</td>
                <td className="border p-3">{p.description}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}