'use client';

import { useState, useEffect, useMemo } from 'react';
import DatePicker from 'react-multi-date-picker';
import persian from "react-date-object/calendars/persian";
import persian_fa from "react-date-object/locales/persian_fa";
import { DateObject } from 'react-multi-date-picker';
import { Bar } from 'react-chartjs-2';
import { Chart as ChartJS, CategoryScale, LinearScale, BarElement, Title, Tooltip, Legend } from 'chart.js';
import { getDailyReport, getAllSales } from '../actions';

ChartJS.register(CategoryScale, LinearScale, BarElement, Title, Tooltip, Legend);

export default function Reports() {
  const [selectedDate, setSelectedDate] = useState(new DateObject());
  const [dailyData, setDailyData] = useState<any[]>([]);
  const [allSales, setAllSales] = useState<any[]>([]);

  const loadDaily = async (dateObj: any) => {
    const persianDate = new DateObject(dateObj).format('YYYY/MM/DD');
    const data = await getDailyReport(persianDate);
    setDailyData(data);
  };

  const loadAll = async () => {
    const data = await getAllSales();
    setAllSales(data);
  };

  useEffect(() => {
    loadDaily(selectedDate);
    loadAll();
  }, [selectedDate]);

  // محاسبات
  const devicesList = ['گرید', 'لیزر میز', 'گردونه', 'ارنا', 'لیزر تگ', 'پکیج 4 تایی', 'پکیج 5 تایی'];
  const dailyDevices = dailyData.filter(d => d.device !== 'کافه');
  const cafe = dailyData.find(d => d.device === 'کافه') || { revenue: 0 };

  const totalTickets = dailyDevices.reduce((sum, d) => sum + d.tickets, 0);
  const totalDevicesRevenue = dailyDevices.reduce((sum, d) => sum + d.revenue, 0);
  const grandTotal = totalDevicesRevenue + cafe.revenue;

  const zeroSales = devicesList.filter(dev => !dailyDevices.some(d => d.device === dev));

  // محاسبه میانگین فروش (30 روز گذشته)
  const avgData = useMemo(() => {
    const map = new Map();
    allSales.forEach(s => {
      if (!map.has(s.device)) map.set(s.device, []);
      map.get(s.device).push(s.revenue);
    });
    const avgMap: any = {};
    map.forEach((revenues, device) => {
      avgMap[device] = revenues.reduce((a: number, b: number) => a + b, 0) / revenues.length || 0;
    });
    return avgMap;
  }, [allSales]);

  // داده‌های نمودار
  const chartData = {
    labels: devicesList,
    datasets: [
      {
        label: 'فروش امروز',
        data: devicesList.map(dev => {
          const item = dailyDevices.find(d => d.device === dev);
          return item ? item.revenue : 0;
        }),
        backgroundColor: '#3b82f6',
      },
      {
        label: 'میانگین فروش',
        data: devicesList.map(dev => avgData[dev] || 0),
        backgroundColor: '#94a3b8',
      }
    ]
  };

  return (
    <div className="space-y-8">
      <div className="flex justify-between items-center">
        <h1 className="text-3xl font-bold">گزارش روزانه</h1>
        <DatePicker
          value={selectedDate}
          onChange={(value: any) => {setSelectedDate(value);}}
          calendar={persian}
          locale={persian_fa}
          inputClass="border p-4 rounded-2xl text-lg"
        />
      </div>

      {/* باکس‌های آماری */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-6">
        <div className="bg-white p-6 rounded-3xl shadow text-center">
          <p className="text-gray-500">جمع تیکت</p>
          <p className="text-5xl font-bold mt-3">{totalTickets}</p>
        </div>
        <div className="bg-white p-6 rounded-3xl shadow text-center">
          <p className="text-gray-500">فروش دستگاه‌ها</p>
          <p className="text-5xl font-bold mt-3 text-blue-600">{totalDevicesRevenue.toLocaleString('fa-IR')}</p>
        </div>
        <div className="bg-white p-6 rounded-3xl shadow text-center">
          <p className="text-gray-500">فروش کافه</p>
          <p className="text-5xl font-bold mt-3 text-amber-600">{cafe.revenue.toLocaleString('fa-IR')}</p>
        </div>
        <div className="bg-white p-6 rounded-3xl shadow text-center">
          <p className="text-gray-500">جمع کل</p>
          <p className="text-5xl font-bold mt-3 text-green-600">{grandTotal.toLocaleString('fa-IR')}</p>
        </div>
        <div className="bg-white p-6 rounded-3xl shadow text-center">
          <p className="text-gray-500">دستگاه بدون فروش</p>
          <p className="text-5xl font-bold mt-3 text-red-600">{zeroSales.length}</p>
        </div>
      </div>

      {/* نمودار */}
      <div className="bg-white p-8 rounded-3xl shadow">
        <h3 className="text-xl font-bold mb-6">مقایسه فروش امروز با میانگین</h3>
        <Bar data={chartData} options={{ responsive: true, maintainAspectRatio: false }} />
      </div>

      {/* جدول کامل */}
      <div className="bg-white rounded-3xl shadow overflow-hidden">
        <table className="w-full">
          <thead>
            <tr className="bg-gray-100">
              <th className="p-4 text-right">دستگاه</th>
              <th className="p-4">تعداد تیکت</th>
              <th className="p-4">مبلغ فروش</th>
              <th className="p-4">میانگین</th>
              <th className="p-4">تفاوت</th>
            </tr>
          </thead>
          <tbody>
            {devicesList.map(dev => {
              const today = dailyDevices.find(d => d.device === dev);
              const avg = avgData[dev] || 0;
              const todayRev = today?.revenue || 0;
              const diff = todayRev - avg;
              const diffPercent = avg > 0 ? ((diff / avg) * 100).toFixed(1) : '—';

              return (
                <tr key={dev} className="border-b hover:bg-gray-50">
                  <td className="p-4 font-medium">{dev}</td>
                  <td className="p-4 text-center">{today?.tickets || 0}</td>
                  <td className="p-4">{todayRev.toLocaleString('fa-IR')}</td>
                  <td className="p-4">{Math.round(avg).toLocaleString('fa-IR')}</td>
                  <td className={`p-4 font-medium ${diff >= 0 ? 'text-green-600' : 'text-red-600'}`}>
                    {diffPercent === '—' ? '—' : `${diffPercent}%`}
                  </td>
                </tr>
              );
            })}
            {/* ردیف کافه */}
            <tr className="bg-amber-50 font-medium">
              <td className="p-4">کافه</td>
              <td className="p-4 text-center">—</td>
              <td className="p-4">{cafe.revenue.toLocaleString('fa-IR')}</td>
              <td className="p-4">—</td>
              <td className="p-4">—</td>
            </tr>
          </tbody>
        </table>
      </div>
    </div>
  );
}