'use client';

import { useState, useEffect } from 'react';
import DatePicker from 'react-multi-date-picker';
import persian from "react-date-object/calendars/persian";
import persian_fa from "react-date-object/locales/persian_fa";
import { DateObject } from 'react-multi-date-picker';   // ← اضافه شد
import { addDailySales, getPrices, getSalesByDate, deleteSalesByDate } from '../actions';


const devices = ['گرید', 'لیزر میز', 'گردونه', 'ارنا', 'لیزر تگ', 'پکیج 4 تایی', 'پکیج 5 تایی'];

export default function DailyEntry() {
    const [date, setDate] = useState<DateObject | Date>(new DateObject());
    const [entries, setEntries] = useState<Record<string, number>>({});
    const [cafeAmount, setCafeAmount] = useState(0);
    const [currentPrices, setCurrentPrices] = useState<Record<string, number>>({});
    const [loading, setLoading] = useState(false);
    const [selectedDate, setSelectedDate] = useState(new DateObject());
    const [existingSales, setExistingSales] = useState<any[]>([]);
    const [isEditMode, setIsEditMode] = useState(false);

    useEffect(() => {
        getPrices().then(result => {
            const priceMap: Record<string, number> = {};
            result.forEach((p: any) => priceMap[p.device] = p.price);
            setCurrentPrices(priceMap);
        });
    }, []);
    useEffect(() => {
        loadSalesForDate(selectedDate);
    }, [selectedDate]);
    const calculateRevenue = (device: string, tickets: number) => {
        return (currentPrices[device] || 0) * tickets;
    };
    const loadSalesForDate = async (dateObj: any) => {
        const persianDate = new DateObject(dateObj).format('YYYY/MM/DD');
        const sales = await getSalesByDate(persianDate);
        setExistingSales(sales);
        setIsEditMode(sales.length > 0);

        // پر کردن فرم برای ویرایش
        const formData: Record<string, number> = {};
        sales.forEach((s: any) => {
            if (s.device === 'کافه') {
                setCafeAmount(s.revenue);
            } else {
                formData[s.device] = s.tickets;
            }
        });
        setEntries(formData);
    };
    const saveDaily = async () => {
        setLoading(true);
        const persianDate = new DateObject(selectedDate).format('YYYY/MM/DD');
        await deleteSalesByDate(persianDate);
        const salesArray: any[] = [];

        // دستگاه‌ها
        Object.entries(entries).forEach(([device, tickets]) => {
            if (tickets > 0) {
                salesArray.push({
                    date: persianDate,
                    device,
                    tickets,
                    revenue: calculateRevenue(device, tickets)
                });
            }
        });

        // کافه
        if (cafeAmount > 0) {
            salesArray.push({
                date: persianDate,
                device: 'کافه',
                tickets: 0,
                revenue: cafeAmount
            });
        }

        await addDailySales(salesArray);   // بعداً upsert بهتر می‌کنیم
        alert(isEditMode ? '✅ ویرایش با موفقیت انجام شد' : '✅ اطلاعات جدید ذخیره شد');

        loadSalesForDate(selectedDate); // بروزرسانی
        setLoading(false);
    };


    const handleDateChange = (value: any) => {
        setSelectedDate(value);
    };
    return (
        <div className="bg-white p-6 rounded-xl shadow">
            <h2 className="text-2xl font-bold mb-6">ورود فروش روزانه</h2>

            <div className="mb-6">
                <label className="block mb-2 font-medium">تاریخ شمسی</label>
                <DatePicker
                    value={date}
                    onChange={handleDateChange}
                    // onChange={(date) => setSelectedDate(date)}
                    calendar={persian}
                    locale={persian_fa}
                    inputClass="border p-3 rounded-lg w-full text-center text-lg"
                    containerClassName="w-full"
                />
            </div>

            {/* بقیه کد فرم همان قبلی */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                {devices.map(device => (
                    <div key={device} className="border p-4 rounded-lg">
                        <label className="block font-medium mb-2">{device}</label>
                        <input
                            type="number"
                            placeholder="تعداد تیکت"
                            value={entries[device] || ''}
                            onChange={(e) => setEntries({ ...entries, [device]: Number(e.target.value) })}
                            className="border p-3 rounded-lg w-full"
                        />
                        <p className="text-sm text-gray-600 mt-2">
                            جمع: {calculateRevenue(device, entries[device] || 0).toLocaleString('fa-IR')} ریال
                        </p>
                    </div>
                ))}

                <div className="border p-4 rounded-lg bg-amber-50">
                    <label className="block font-medium mb-2">کافه (مبلغ مستقیم)</label>
                    <input
                        type="number"
                        placeholder="مبلغ فروش کافه"
                        value={cafeAmount || ''}
                        onChange={(e) => setCafeAmount(Number(e.target.value))}
                        className="border p-3 rounded-lg w-full"
                    />
                </div>
            </div>

            <button
                onClick={saveDaily}
                disabled={loading}
                className="mt-8 bg-green-600 text-white w-full py-4 rounded-xl text-lg font-bold hover:bg-green-700 disabled:opacity-50"
            >
                {loading ? 'در حال ذخیره...' : '💾 ذخیره فروش روزانه'}
            </button>
        </div>
    );
}