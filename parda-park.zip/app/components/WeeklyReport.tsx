'use client';

import { useState, useEffect } from 'react';
import { getAllSales } from '../actions';


export default function WeeklyReport() {
  const [reportData, setReportData] = useState<any[]>([]);
  const [loading, setLoading] = useState(false);

  const loadReport = async () => {
    setLoading(true);
    const result = await getAllSales();
    setReportData(result);
    setLoading(false);
  };

  useEffect(() => {
    loadReport();
  }, []);

  const totalRevenue = reportData.reduce((sum, r) => sum + r.revenue, 0);

  return (
    <div className="bg-white p-6 rounded-xl shadow">
      <div className="flex justify-between items-center mb-6">
        <h2 className="text-2xl font-bold">گزارش فروش</h2>
        <button 
          onClick={loadReport}
          disabled={loading}
          className="bg-blue-600 text-white px-6 py-2 rounded-lg hover:bg-blue-700"
        >
          {loading ? 'در حال بروزرسانی...' : '🔄 بروزرسانی'}
        </button>
      </div>

      <div className="overflow-x-auto">
        <table className="w-full border-collapse border text-sm">
          <thead>
            <tr className="bg-gray-100">
              <th className="border p-3">تاریخ</th>
              <th className="border p-3">دستگاه</th>
              <th className="border p-3">تعداد تیکت</th>
              <th className="border p-3">جمع فروش</th>
            </tr>
          </thead>
          <tbody>
            {reportData.map((row, i) => (
              <tr key={i} className="hover:bg-gray-50">
                <td className="border p-3">{row.date}</td>
                <td className="border p-3">{row.device}</td>
                <td className="border p-3 text-center">{row.tickets}</td>
                <td className="border p-3 font-medium">
                  {row.revenue.toLocaleString('fa-IR')} ریال
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {totalRevenue > 0 && (
        <div className="mt-8 p-8 bg-blue-50 rounded-2xl text-center">
          <p className="text-3xl font-bold text-blue-700">
            مجموع کل فروش: {totalRevenue.toLocaleString('fa-IR')} ریال
          </p>
        </div>
      )}
    </div>
  );
}