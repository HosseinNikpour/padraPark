'use server';

import { db } from '../db';
import { prices, dailySales } from '../db/schema';
import { eq } from 'drizzle-orm';

export async function getPrices() {
  return await db.select().from(prices).orderBy(prices.date);//,'desc' 
}
export async function addPrice(device: string, price: number, description = '') {
  try {
    await db.insert(prices).values({
      device,
      price,
      date: new Date().toISOString().split('T')[0],
      description,
    });
    return { success: true };
  } catch (error) {
    console.error(error);
    return { success: false };
  }
}
export async function addDailySales(sales: any[]) {
  await db.insert(dailySales).values(sales);
  return { success: true };
}
export async function getAllSales() {
  return await db.select().from(dailySales).orderBy(dailySales.date);
}
export async function updateDailySale(id: number, data: { tickets?: number; revenue?: number }) {
  try {
    await db.update(dailySales)
      .set(data)
      .where(eq(dailySales.id, id));
    return { success: true };
  } catch (error) {
    return { success: false };
  }
}
export async function deleteSalesByDate(date: string) {
  try {
    await db.delete(dailySales).where(eq(dailySales.date, date));
    return { success: true };
  } catch (error) {
    console.error(error);
    return { success: false };
  }
}
export async function getSalesByDate(date: string) {
  return await db.select().from(dailySales).where(eq(dailySales.date, date));
}
export async function getDailyReport(date: string) {
  return await db.select().from(dailySales).where(eq(dailySales.date, date));
}
export async function getSalesForAverage(days: number = 30) {
  const result = await db.select().from(dailySales);
  return result;
}