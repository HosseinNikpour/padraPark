'use client';

import { useState } from 'react';
import PriceForm from './components/PriceForm';
import DailyEntry from './components/DailyEntry';
import WeeklyReport from './components/WeeklyReport';
import Reports from './components/Reports';

export default function Home() {
  const [activeTab, setActiveTab] = useState<'price' | 'daily' | 'report'>('price'); // پیش‌فرض روی قیمت پایه

  return (
    <div className="min-h-screen bg-gray-50 p-4 md:p-6" dir="rtl">
      <div className="max-w-7xl mx-auto">
        <h1 className="text-4xl font-bold text-center mb-10 text-blue-700">
          🛠️ سیستم مدیریت فروش مجموعه تفریحی
        </h1>

        {/* تب‌ها */}
        <div className="flex flex-wrap justify-center gap-2 mb-8 bg-white p-2 rounded-2xl shadow-sm">
          <button
            onClick={() => setActiveTab('price')}
            className={`px-8 py-4 rounded-xl font-semibold text-lg transition-all ${
              activeTab === 'price' 
                ? 'bg-blue-600 text-white shadow' 
                : 'bg-gray-100 hover:bg-gray-200 text-gray-700'
            }`}
          >
            📋 قیمت پایه دستگاه‌ها
          </button>

          <button
            onClick={() => setActiveTab('daily')}
            className={`px-8 py-4 rounded-xl font-semibold text-lg transition-all ${
              activeTab === 'daily' 
                ? 'bg-blue-600 text-white shadow' 
                : 'bg-gray-100 hover:bg-gray-200 text-gray-700'
            }`}
          >
            📝 ورود فروش روزانه
          </button>

          <button
            onClick={() => setActiveTab('report')}
            className={`px-8 py-4 rounded-xl font-semibold text-lg transition-all ${
              activeTab === 'report' 
                ? 'bg-blue-600 text-white shadow' 
                : 'bg-gray-100 hover:bg-gray-200 text-gray-700'
            }`}
          >
            📊 گزارش فروش
          </button>
        </div>

        {/* محتوای تب‌ها */}
        <div className="bg-white rounded-3xl shadow-xl p-6 md:p-8">
          {activeTab === 'price' && <PriceForm />}
          {activeTab === 'daily' && <DailyEntry />}
          {activeTab === 'report' && <Reports />}
        </div>
      </div>
    </div>
  );
}